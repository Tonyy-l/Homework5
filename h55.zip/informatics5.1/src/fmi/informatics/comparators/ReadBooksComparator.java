package fmi.informatics.comparators;

import fmi.informatics.extending.Person;

public class ReadBooksComparator extends PersonComparator {

	@Override
	public int compare(Person o1, Person o2) {
		Integer readBooks1 = Integer.valueOf(o1.getReadBooks());
		Integer readBooks2 = Integer.valueOf(o2.getReadBooks());
		if (readBooks1.equals(readBooks2)) {

			return 0;
		}

		else {

			return (readBooks1.compareTo(readBooks2)) * sortOrder;

		}

	}

}
