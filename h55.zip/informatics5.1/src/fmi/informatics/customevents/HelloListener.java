package fmi.informatics.customevents;

public interface HelloListener {
	
	void respondGreeting();

}
