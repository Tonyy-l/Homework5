package fmi.informatics.nestedclasses;

// Eнумератор AnimalName с имена на животни, които се подават като параметър на конструктора
// на клас MysteryAnimal. В него се съдържа логика какво животно да се създаде – крава, 
// котка или куче, а то от своя страна записва в този клас звука, който издава.
public enum AnimalName { 
	Bella, 
	Chloe, 
	Molly,
	Betty
}
