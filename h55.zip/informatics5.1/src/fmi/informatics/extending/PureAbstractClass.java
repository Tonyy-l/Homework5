package fmi.informatics.extending;

/**
 * 
 * @author Konstantin Rusev
 *
 */
public abstract class PureAbstractClass { // пример за чист абстрактен клас
	public abstract void test();
}
