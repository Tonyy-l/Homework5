package fmi.informatics.interfaces;

/**
 * 
 * @author Konstantin Rusev
 *
 */
public interface Adaptable {
	
	public void study();
	
	public void think();
	
	public void act();
}
