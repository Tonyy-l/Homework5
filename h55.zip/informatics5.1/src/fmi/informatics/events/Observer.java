package fmi.informatics.events;

// създаваме интерфейс Observer (наблюдател)
public interface Observer {
	
	void update();

}
